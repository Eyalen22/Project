import hashlib
import os
import sys
import shutil
import PyInstaller.__main__
import ctypes
from pathlib import Path


def run_full_process(drive_letter, username, password, mail):
    """Executes the full automated build process: hashes credentials, packages the script into an EXE, and transfers it to the USB drive"""
    #לשנות לפי איפה שנמצא הקובץ המחשב חשוב בטירוף אחרת ההורדה לא תעבוד
    base_folder = Path(r"E:/Project/project_dok/client")
    main_script = base_folder / "client_logic.py"
    vault_path = base_folder / ".auth_vault"
    exe_name = "OPEN_DOK"
    usb_drive_str = f"{drive_letter.upper()}"
    print(f"\n--- Starting Build Process (Hybrid OS/Pathlib) ---")
    if not os.path.exists(usb_drive_str):
        print(f"CRITICAL ERROR: Drive {usb_drive_str} not found!")
        return "01"
    usb_path = Path(usb_drive_str)
    final_exe_path = usb_path / f"{exe_name}.exe"
    final_secret_path = usb_path / ".send_back_up"

    try:
        u_hash = hashlib.sha256(username.encode()).hexdigest()
        p_hash = hashlib.sha256(password.encode()).hexdigest()
        vault_path.write_text(f"{u_hash}\n{p_hash}\n{mail}", encoding="utf-8")

        print(f"Packaging {exe_name}.exe... Please wait.")

        # 2. Running PyInstaller (Requires strings)
        PyInstaller.__main__.run([
            str(main_script),
            '--onefile',
            '--noconsole',
            f'--name={exe_name}',
            f'--add-data={str(vault_path)}{os.pathsep}.',
            f'--paths={str(base_folder)}',
            '--clean',
            '--log-level=WARN'
        ])

        # 3. Moving to DOK and managing the backup file
        source_exe = Path("dist") / f"{exe_name}.exe"

        if source_exe.exists():
            print(f"Copying EXE to {usb_drive_str}...")
            # Use shutil for file copying
            shutil.copy2(source_exe, final_exe_path)
        else:
            print("Error: EXE was not created.")
            return "01"
        if final_secret_path.exists():
            if os.name == 'nt':
                ctypes.windll.kernel32.SetFileAttributesW(str(final_secret_path), 0x80)
        final_secret_path.write_text("", encoding="utf-8")
        if os.name == 'nt':
            ctypes.windll.kernel32.SetFileAttributesW(str(final_secret_path), 0x06)

        print(f"SUCCESS! Ready on {usb_drive_str}")

    except Exception as e:
        print(f"Error during process: {e}")
    finally:
        print("Cleaning up...")
        for folder_name in ['build', 'dist']:
            folder = Path(folder_name)
            if folder.exists():
                shutil.rmtree(folder, ignore_errors=True)

        for f in [Path(f"{exe_name}.spec"), vault_path]:
            if f.exists():
                try:
                    f.unlink()
                except:
                    pass

    return "00"


if __name__ == "__main__":
    u, p = run_full_process("F")
    print(f"\nFinal Status: Build complete for user '{u}'.")